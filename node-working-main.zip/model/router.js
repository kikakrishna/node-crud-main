const router = require("express").Router();
const { checkToken } = require("../auth/tokenvalidation");
const {
    getUsers,
    login,
    getsingleUsers,
} = require("./controller")

router.post("/login", login);
router.get("/", checkToken, getUsers);
router.get("/getuser/:id", checkToken, getsingleUsers);


module.exports = router