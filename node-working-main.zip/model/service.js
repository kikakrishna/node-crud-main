const pool = require("../config/database");


module.exports = {
    getUsers: callBack => {
        const sqlget = "SELECT * FROM sample";
        pool.query(`SELECT * FROM sample`, (error, result) => {
            if (error) {
                return callBack(error);
            }
            return callBack(null, result);

        }

        )
    },
    getUserByUserEmail: (Email, callBack) => {
        // console.log(Email, "server");
        // console.log("fefefefefe");

        const sqlget = "SELECT * FROM auth WHERE name = ?";

        pool.query(sqlget, [Email], (error, results, fields) => {
            // console.log(results, "resultsserver");


            if (error) {
                return callBack(error);
            }
            return callBack(null, results[0]);
        }
        );
    },
    getsingleUsers: (id, callBack) => {
        console.log(id);
        const sqlget = "SELECT FROM new WHERE PersonID = ?";
        pool.query(`SELECT * FROM new WHERE id = ?`, [id], (error, result) => {
            if (error) {
                return callBack(error);
            }
            return callBack(null, result);

        }

        )
    },
}